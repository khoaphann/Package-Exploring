import java.io.*;
import java.lang.reflect.*;
import java.util.*;

/**
 * 
 * @author Khoa Phan
 *
 */

public class HW5
{
	
	
	private static String path = ".";
	private static String[] classNames;
	private static File[] fileList;
	private static Scanner input;
	private static HashMap<String, ClassData> hashMap = new HashMap<>();
	    
	public static void main(String[] args) throws Exception 
	{
		 if (args.length > 0 && args[0] != null) 
		 {
	            path = args[0];
	     }
		 else	        	
	     {				
	            //path = System.getProperty("user.dir") + "/";
	            path = "C:\\Users\\Khoa Phan\\eclipse-workspace\\151HW5\\bin\\";
			 //path = "/sjsu/testerProject/out/production/testerProject/";
	     }	 
	
		 input = new Scanner(System.in);
		 char mainMenuChoice, subMenuChoice;
		 String fileName;
		 int tempInput = -1;
		 
		 do
		 {
			System.out.println("\nWelcome to PackageExplorer - Main Menu");
			System.out.println("--------------------------------------");
			System.out.println("   1.List all classes");
			System.out.println("   2.View a class");
			System.out.println("   3.Save all classes");
			System.out.println("   4.Load class info from xml");
			System.out.print("Enter your choice (1-4) or q to quit: ");
			mainMenuChoice = input.next().charAt(0);

			switch (mainMenuChoice)
			{
			case '1':
				packageLoader();
				if (hashMap.size() > 0)
				{
					System.out.println("Gathering class files in " + path);
					System.out.println("\t\tList of classes");
					System.out.println("------------------------------------------------------------------------------");
					for(int i = 0; i < classNames.length; i++){
						System.out.println(i + 1 + ". " + classNames[i]);
					}
					do
					{
						System.out.print("\nEnter (1-" + hashMap.size() + ") to view details or m for main menu: ");
						fileName = input.next();
						mainMenuChoice = fileName.charAt(0);
						try
						{
							tempInput = Integer.parseInt(fileName);
	                    } catch (Exception e) {
	                    	tempInput = 0;
	                    }
					}
					while(mainMenuChoice != 'm' && (tempInput > hashMap.size() || tempInput < 1));
					if (mainMenuChoice == 'm')
						break;
					tempInput--;
					ClassData _classData = hashMap.get(classNames[tempInput]);
					viewClassDetail(_classData);
					do
					{
						System.out.print("\nEnter s to save or m for Main menu: ");
						mainMenuChoice = input.next().charAt(0);
					}
					while (mainMenuChoice != 'm' && mainMenuChoice != 's');
					if (mainMenuChoice == 's')
					{
		                hashMap = new HashMap<>();
		                hashMap.put(_classData.getName(),_classData);
		                saveFile(_classData.getName() + ".xml"); 
		                System.out.println("Saved class information as " + _classData.getName() + ".xml");
		                break;
					}
					else
					{
						break;
					}
				}
				break;
				
			case '2':
				packageLoader();
				System.out.print("\nEnter class filename: ");
				String fName = input.next();
				File file = new File(path + fName + ".class");
                if(file.exists()) 
                {
                	ClassData cD = hashMap.get(fName);
                	hashMap = new HashMap<>(); // temp for save later
                	viewClassDetail(cD);
                	hashMap.put(cD.getName(), cD);
                	do
					{
						System.out.print("\nEnter s to save or m for Main menu: ");
						mainMenuChoice = input.next().charAt(0);
					}
					while (mainMenuChoice != 'm' && mainMenuChoice != 's');
					if (mainMenuChoice == 's')
					{
		                saveFile(fName + ".xml"); 
		                System.out.println("Saved class information as " + fName + ".xml");
		                break;
					}
					else
					{
						break;
					}
                }
                else
                {
                    System.out.println("Invalid filename or file doesn't exist");
                   
                }
				break;
				
				
				
			case '3':
				packageLoader();
				System.out.print("\nEnter filename + .xml to save: ");
				fileName = input.next();
				
				System.out.print("Is the file's name above is correct? (y/n): \n");
				System.out.println("Enter n to return to main menu.");
				System.out.println("Enter y to continue saving.");
				if (input.next().charAt(0) == 'n')
				{
					break;
				}
				else
				{
				 saveFile(fileName);
				 System.out.println("Saved all classes information as " + fileName);
				}
				break;

				
			}
		 }
		 while (mainMenuChoice != 'q');	
	}

	    public static void packageLoader() throws Exception
	    {
	    	hashMap = new HashMap<>();
	        FilenameFilter classFilter = (dir, name) -> name.toLowerCase().endsWith(".class");
	        File f = new File(path); //  directory
	        fileList = f.listFiles(classFilter);
			classNames = new String[fileList.length];
			for (int i =0; i< fileList.length; i++)
			{
				String name = fileList[i].getName().replace(".class", "");
				Class c = Class.forName(name);
				classNames[i] = name;
				hashMap.put(name, getClassData(c));
	    	}
	    }
	    
	    public static ClassData getClassData(Class _class) throws Exception
		{
			ClassData _classData = new ClassData();

		    _classData.setName(_class.getCanonicalName());
		    if(_class.getSuperclass() != null) {
				_classData.setSuperClass(_class.getSuperclass().getName());
			} else
				_classData.setSuperClass(null);

		    if(_class.getInterfaces().length > 0) {
				String[] interfaces = new String[_class.getInterfaces().length];
				for (int i = 0; i < interfaces.length; i++)
					interfaces[i] = _class.getInterfaces()[i].getCanonicalName();

				_classData.setInterfaces(interfaces);
			} else
				_classData.setInterfaces(null);

		    String[] methods = new String[_class.getDeclaredMethods().length];
		    for (int i = 0; i < methods.length; i++)
		    	methods[i] = _class.getDeclaredMethods()[i].getName() + ": " +
		    				Modifier.toString(_class.getDeclaredMethods()[i].getModifiers());
		    _classData.setMethods(methods);

		    String[] fields = new String[_class.getDeclaredFields().length];
		    for (int i = 0; i < fields.length; i++)
		        fields[i] = _class.getDeclaredFields()[i].getName();
		    _classData.setFields(fields);

		    Field[] field = _class.getDeclaredFields();
		    
			String[] providers = new String[field.length];
		    for (int i = 0; i < providers.length; i++)
		        providers[i] = field[i].getType().getCanonicalName();
		    String[] providers2 = new String[providers.length];
		    
		    int temp = 0;
		    for (int i = 0; i < providers.length; i++)
		    	for (int j = 0; j < fileList.length; j++)
		    		if (providers[i].equals(fileList[j].getName().replace(".class", "")))
		    		{
		    			providers2[temp++] = providers[i];		    			
		    		}
		    _classData.setProviders(providers2);

		    String [] clients = new String[fileList.length];
	        int count = 0;
	        for(int i = 0; i < fileList.length; i++)
	        {
	            if(fileList[i]!= null)
	            {
					String className = fileList[i].getName().replace(".class", "");
	             	if(!_class.getCanonicalName().equals(className))
	             	{
						Class _c = Class.forName(className);
						Field[] fieldList = _c.getDeclaredFields();
						for(Field fld: fieldList)
						{
							String providerName = fld.getType().getCanonicalName();
							if(_class.getCanonicalName().equals(providerName))
							{
								clients[count] = className;
								count++;
							}
						}
					}
	           }
	        }
	        _classData.setClients(clients);
		    return _classData;
		}

	    public static void viewClassDetail(ClassData data)
	    {
	        String className = data.getName();
	        String superClass = data.getSuperClass();
	        String[] interfaces = data.getInterfaces();
	        String[] methods = data.getMethods();
	        String[] fields = data.getFields();
	        String[] providers = data.getProviders();
	        String[] clients = data.getClients();
	        System.out.println("Name: " + className);
	        System.out.print("Superclass: ");
	        if (superClass == null) 
	        	System.out.println("None");
			else
				System.out.println(superClass);
	        System.out.print("Interface: ");
	        if (interfaces == null) 
	        	System.out.print("None\n");
	         else 
	        	 for (String i : interfaces) 
		                System.out.println("\t" + i);
	        System.out.println("Fields: ");
	        if (fields == null) 
	        	System.out.print("\tNone\n");
	         else 
	        	 for (String f : fields) 
		                System.out.println("\t" + f);
	        System.out.println("Methods: ");
	        if (methods == null) 
	        	System.out.print("\tNone");
	         else
	        	 for (String m : methods) 
		                System.out.println("\t" + m);
	        System.out.println("Providers: ");
	        int index = 0;
	        if (providers == null)
	        {
	        	System.out.print("\tNone\n");
	        }
	        else
	        {
	            for (String p : providers) 
	            {
	                if (p != null)
	                {
	                    System.out.println("\t" + p);
	                    index++;
	                }
	            }
	            if (index == 0)
	                System.out.print("\tNone");
	        }
	        System.out.println("Clients: ");
	        index = 0;
	        if (clients == null) 
	        {
	        	System.out.print("\tNone\n");
	        }
	        else
	        {
	            for (String c : clients) 
	            {
	                if (c != null)
	                {
	                    System.out.println("\t" + c);
	                    index++;
	                }
	            }
	            if (index == 0)
	                System.out.print("\tNone");
	        }
	    }

	
	    public static void saveFile(String name) throws Exception
		{
	        try
	        {
	            ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(name));
	            outputStream.writeObject(hashMap);
	            outputStream.flush();
	            outputStream.close();
	        }
	        catch(Exception ex)
	        {
	        }
	    }
	
	
	public static class ClassData implements Serializable
	{
        String  superClass;
        String fileName;
        String[] interfaces;
        String[] fields;
        String[] providers;
        String[] methods;
        String[] clients;

        public void setName(String fileName)
        {
            this.fileName = fileName;
        }
       
        public String getName()
        {
        	return this.fileName;
        }
        
        public void setSuperClass(String superClass)
        {
            this.superClass = superClass;
        }
        
        public String getSuperClass()
        {
        	return this.superClass;
        }
        
        public void setMethods(String[] methods)
        {
            this.methods = methods;
        }
        
        public String[] getMethods()
        { 
        	return this.methods;
        }
        
        public void setInterfaces(String[] interfaces)
        {
            this.interfaces = interfaces;
        }
        
        public String[] getInterfaces()
        { 
        	return this.interfaces;
        }
               
        public void setProviders(String[] providers)
        {
            this.providers = providers;
        }
        
        public String[] getProviders()
        {
        	return this.providers;
        }
        
        public void setFields(String[] fields)
        {
            this.fields = fields;
        }
        
        public String[] getFields()
        { 
        	return this.fields;
        }
                       
        public void setClients(String[] clients)
        {
            this.clients = clients;
        }
        
        public String[] getClients()
        { 
        	return this.clients;
        }

    }
}
